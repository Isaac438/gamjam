extends Node3D

@export var building: PackedScene
@export var grass: PackedScene
@export var tree: PackedScene
@export var loading_screen: PackedScene
@export var road: PackedScene
@export var road_center: PackedScene

func make_block(x: float, z: float) -> void:
	#var loading_screen1 = loading_screen.instantiate()
	#add_child(loading_screen1)
	
	#geneate corners
	var road_center1 = road_center.instantiate()
	add_child(road_center1)
	road_center1.global_position = Vector3(x, 0, z)
	var road_center2 = road_center.instantiate()
	add_child(road_center2)
	road_center2.global_position = Vector3(x + 32.0, 0, z)
	var road_center3 = road_center.instantiate()
	add_child(road_center3)
	road_center3.global_position = Vector3(x, 0, z + 32.0)
	var road_center4 = road_center.instantiate()
	add_child(road_center4)
	road_center4.global_position = Vector3(x + 32.0, 0, z + 32.0)
	
	#generate edges
	
	var road1 = road.instantiate()
	if !is_overlapping(road1):
		add_child(road1)
		road1.global_position = Vector3(x, 0.0, z + 16.0)
	else:
		global.debug_message = "found overlap somehow cause u dum"
	var road2 = road.instantiate()
	if !is_overlapping(road2):
		add_child(road2)
		road2.global_position = Vector3(x + 16.0, 0.0, z)
		road2.set_rotation(Vector3(0.0, deg_to_rad(90.0), 0.0))
	var road3 = road.instantiate()
	if !is_overlapping(road3):
		add_child(road3)
		road3.global_position = Vector3(x+32.0, 0.0, z+16.0)
	var road4 = road.instantiate()
	if !is_overlapping(road4):
		add_child(road4)
		road4.global_position = Vector3(x+16.0, 0.0, z+32.0)
		road4.set_rotation(Vector3(0.0, deg_to_rad(90.0), 0.0))
	
	#generate center randomly

	if randi_range(0,1) == 0:
		var building1 = building.instantiate()
		add_child(building1)
		building1.global_position = Vector3(x+16.0, 0.0, z+16.0)
		var rand_rotate = randi_range(0,3)
		if rand_rotate == 1:
			rand_rotate = deg_to_rad(90.0)
		elif rand_rotate == 2:
			rand_rotate = deg_to_rad(180.0)
		elif rand_rotate == 3:
			rand_rotate = deg_to_rad(270.0)
		building1.set_rotation(Vector3(0.0, rand_rotate, 0.0))
	else:
		#park generation; do later
		pass
		
	#loading_screen.queue_free()
	
func _ready() -> void:
	for x in range(10):
		for z in range(10):
			make_block(x*32,z*32)
	
func is_overlapping(piece: Node3D):
	for child in self.get_children():
		if child.global_positon == piece.global_position and child != piece:
			return true
	return false
	
