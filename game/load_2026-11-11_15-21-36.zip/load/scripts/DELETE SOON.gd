extends NavigationRegion3D

@export var map: Node3D
func _ready() -> void:
	await get_parent().ready
	await map.ready
	
	self.bake_navigation_mesh()
