extends VehicleBody3D

@export var nav_agent: NavigationAgent3D

func _ready() -> void:
	nav_agent.target_position = global.player_position

var t := 0.0
func _process(delta: float) -> void:
	t += delta
	if t > 1.0:
		t = 0.0
		nav_agent.target_position = global.player_position
