extends Node

var debug_message := "welcome to your driver's test"
var player_position := Vector3(0.0, 5.0, 0.0)
